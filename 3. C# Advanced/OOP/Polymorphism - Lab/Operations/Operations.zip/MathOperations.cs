﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Operations
{
    public class MathOperations
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

        public double Add(double a, double b, double c)
        {
            double result = a + b + c;
            return result;
        }

        public decimal Add(decimal a, decimal b, decimal c)
        {
            decimal result = a + b + c;
            return result;
        }
    }
}
