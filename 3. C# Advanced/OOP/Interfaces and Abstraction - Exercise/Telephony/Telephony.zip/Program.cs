﻿using System;

namespace Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] phoneNumbers = Console.ReadLine()
                .Split(" ");
            string[] websites = Console.ReadLine()
                .Split(" ");
            ICallable phone;
            foreach (string phoneNumber in phoneNumbers)
            {

                if (phoneNumber.Length == 10)
                {
                    phone = new Smartphone();

                }
                else
                {
                    phone = new StationaryPhone();
                }
                try
                {
                    phone.Call(phoneNumber);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            IBrowsable smartphone = new Smartphone();
            foreach (string website in websites)
            {

                try
                {
                    smartphone.Browse(website);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

        }
    }
}
