﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExplicitInterfaces.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
