﻿using MilitaryElite.Core.Interfaces;
using MilitaryElite.Enums;
using MilitaryElite.Models;
using MilitaryElite.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Core
{
    public class Engine : IEngine
    {
        //Dictionary<int, ISoldier> soldiers;
        List<ISoldier> soldiers;
        List<IPrivate> privates;
        public Engine()
        {
            //soldiers = new Dictionary<int, ISoldier>();
            soldiers = new List<ISoldier>();
            privates = new List<IPrivate>();
        }

        public void Run()
        {
            

            string input = string.Empty;
            IPrivate soldier;
            while((input = Console.ReadLine()) != "End")
            {
                string[] strings = input
                    .Split(" ");
                Queue<string> inputElements = new Queue<string>(strings);
                string command = inputElements.Dequeue();
                int id = int.Parse(inputElements.Dequeue());
                string firstName = inputElements.Dequeue();
                string lastName = inputElements.Dequeue();
                switch (command)
                {
                    case "Private":
                        decimal salary = decimal.Parse(inputElements.Dequeue());
                        soldier = new Private(id, firstName, lastName, salary);
                        soldiers.Add(soldier);
                        privates.Add(soldier);
                        break;
                    case "LieutenantGeneral":
                        decimal salary1 = decimal.Parse(inputElements.Dequeue());
                        List<IPrivate> privatesForAdd = new List<IPrivate>();
                        while(inputElements.Count > 0)
                        {
                            int currentId = int.Parse(inputElements.Dequeue());
                            soldier = privates.Find(v => v.Id == currentId);
                            privatesForAdd.Add(soldier);
                        }
                        soldier = new LieutenantGeneral(id, firstName, lastName, salary1, privatesForAdd);
                        soldiers.Add(soldier);
                        break;
                    case "Engineer":
                        decimal salary2 = decimal.Parse(inputElements.Dequeue());
                        string corpString = inputElements.Dequeue();
                        Corps corp;
                        //if(!(corp == Corps.Marines.ToString() || corp == Corps.Airforces.ToString()))
                        //{
                        //    continue;
                        //}
                        if (corpString == Corps.Airforces.ToString())
                        {
                            corp = Corps.Airforces;
                        }
                        else if(corpString == Corps.Marines.ToString())
                        {
                            corp = Corps.Marines;
                        }
                        else
                        {
                            continue;
                        }
                        List<IRepair> repairs = new List<IRepair>();
                        IRepair repair;
                        while (inputElements.Count > 0)
                        {
                            string partName = inputElements.Dequeue();
                            int hoursForRepairing = int.Parse(inputElements.Dequeue());
                            repair = new Repair(partName, hoursForRepairing);
                            repairs.Add(repair);
                        }
                        soldier = new Engineer(id, firstName, lastName, salary2, corp, repairs);
                        soldiers.Add(soldier);
                        break;
                    case "Commando":
                        decimal salary3 = decimal.Parse(inputElements.Dequeue());
                        string corpString1 = inputElements.Dequeue();
                        Corps corp1;
                        //if(!(corp == Corps.Marines.ToString() || corp == Corps.Airforces.ToString()))
                        //{
                        //    continue;
                        //}
                        if (corpString1 == Corps.Airforces.ToString())
                        {
                            corp1 = Corps.Airforces;
                        }
                        else if (corpString1 == Corps.Marines.ToString())
                        {
                            corp1 = Corps.Marines;
                        }
                        else
                        {
                            continue;
                        }
                        List<IMission> missions = new List<IMission>();
                        MissionState missionState;
                        IMission mission;
                        while (inputElements.Count > 0)
                        {
                            string partName = inputElements.Dequeue();
                            string missionStateString = inputElements.Dequeue();
                            if (missionStateString == MissionState.inProgress.ToString())
                            {
                                missionState = MissionState.inProgress;
                            }
                            else if (missionStateString == MissionState.Finished.ToString())
                            {
                                missionState = MissionState.Finished;
                            }
                            else
                            {
                                continue;
                            }
                            mission = new Mission(partName, missionState);
                            missions.Add(mission);
                        }
                        soldier = new Commando(id, firstName, lastName, salary3, corp1, missions);
                        soldiers.Add(soldier);
                        break;
                    case "Spy":
                        ISpy spySoldier;
                        int spyCodeNumber = int.Parse(inputElements.Dequeue());
                        spySoldier = new Spy(id, firstName, lastName, spyCodeNumber);
                        soldiers.Add(spySoldier);
                        break;
                }
            }
            foreach (var currentSoldier in soldiers)
            {
                Console.WriteLine(currentSoldier);
            }
        }
    }
}
