﻿namespace INStock.Tests
{
    public class ProductTests
    {
    }
}
