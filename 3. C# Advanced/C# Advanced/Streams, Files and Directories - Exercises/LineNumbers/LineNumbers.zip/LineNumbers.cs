﻿namespace LineNumbers
{
    using System;
    using System.IO;

    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";
            string outputFilePath = @"..\..\..\output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            string[] lines = File.ReadAllLines(inputFilePath);
            for (int v = 0; v < lines.Length; v++)
            {
                int letters = 0;
                int punctuationMarks = 0;
                foreach (char c in lines[v])
                {
                    if (c == ' ')
                    {
                        continue;
                    }
                    else if (!char.IsLetterOrDigit(c))
                    {
                        punctuationMarks++;
                    }
                    else
                    {
                        letters++;
                    }
                }
                lines[v] = $"Line {v + 1}: {lines[v]} ({letters}) ({punctuationMarks})";
            }
            File.WriteAllLines(outputFilePath, lines);


        }
    }
}
