﻿namespace CopyBinaryFile
{
    using System;
    using System.IO;

    public class CopyBinaryFile
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\copyMe.png";
            string outputFilePath = @"..\..\..\copyMe-copy.png";

            CopyFile(inputFilePath, outputFilePath);
        }

        public static void CopyFile(string inputFilePath, string outputFilePath)
        {
            using (FileStream readFile = new FileStream(inputFilePath, FileMode.Open))
            {
                using (FileStream writeFile = new FileStream(outputFilePath, FileMode.CreateNew))
                {
                    byte[] buffer = new byte[2048];
                    int size = 0;
                    while((size = readFile.Read(buffer, 0, buffer.Length)) != 0)
                    {
                        writeFile.Write(buffer, 0, size);
                    }
                }
            }
        }
    }
}
