﻿namespace SoftUniKindergarten
{
    public class Kindergarten
    {

    }
}
