﻿using System;

namespace ComputerArchitecture
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Computer computer = new Computer("ddz", 4);
            //CPU cpu1 = new CPU("nz1", 2, 1.5);
            //CPU cpu2 = new CPU("nz2", 4, 3.5);
            //CPU cpu3 = new CPU("nz3", 6, 2.5);
            //computer.Add(cpu1);
            //computer.Add(cpu2);
            //computer.Add(cpu3);
            //CPU cpu = computer.MostPowerful();
            //Console.WriteLine(cpu.ToString());
            //Console.WriteLine();

            
        }
    }
}
