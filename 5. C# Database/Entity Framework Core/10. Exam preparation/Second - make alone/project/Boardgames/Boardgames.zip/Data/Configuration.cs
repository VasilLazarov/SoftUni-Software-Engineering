﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=PC-VAT\SQLEXPRESS;Database=Boardgames;Integrated Security=true;TrustServerCertificate=True";
    }
}
