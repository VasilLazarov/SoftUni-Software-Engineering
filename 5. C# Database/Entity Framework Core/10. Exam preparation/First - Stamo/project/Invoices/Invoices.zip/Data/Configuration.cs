﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=PC-VAT\SQLEXPRESS;Database=Invoices;Integrated Security=true;TrustServerCertificate=True";
    }
}
