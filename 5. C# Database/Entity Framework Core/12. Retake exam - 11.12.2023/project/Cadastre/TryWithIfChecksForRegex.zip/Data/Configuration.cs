﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=PC-VAT\SQLEXPRESS;Database=Cadastre;Integrated Security=true;TrustServerCertificate=True";
    }
}
