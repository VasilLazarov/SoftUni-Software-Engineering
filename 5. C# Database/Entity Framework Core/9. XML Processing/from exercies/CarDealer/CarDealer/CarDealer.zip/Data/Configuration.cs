﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = 
            @"Server=PC-VAT\SQLEXPRESS;Database=CarDealer;Integrated Security=true;TrustServerCertificate=True";
    }
}
