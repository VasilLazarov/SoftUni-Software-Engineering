﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=PC-VAT\SQLEXPRESS;Database=ProductShop;Integrated Security=true;TrustServerCertificate=True";
    }
}
