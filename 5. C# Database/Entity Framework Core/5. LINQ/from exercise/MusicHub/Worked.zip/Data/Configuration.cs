﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=PC-VAT\SQLEXPRESS;Database=MusicHub;Integrated Security=true;TrustServerCertificate=True";
    }
}
